const socket = io();

// DOM Elements
const targetInput = document.getElementById('targetNumber');
const reportBtn = document.getElementById('reportBtn');
const checkInput = document.getElementById('checkNumber');
const checkBtn = document.getElementById('checkBtn');
const historyList = document.getElementById('historyList');
const totalReports = document.getElementById('totalReports');
const bannedAccounts = document.getElementById('bannedAccounts');
const safeAccounts = document.getElementById('safeAccounts');
const activeReports = document.getElementById('activeReports');
const checkResult = document.getElementById('checkResult');
const bulkBtn = document.getElementById('bulkBtn');
const clearHistoryBtn = document.getElementById('clearHistory');
const exportBtn = document.getElementById('exportData');

// Socket.io - Real time stats
socket.on('statsUpdate', (stats) => {
  totalReports.textContent = stats.totalReports || 0;
  bannedAccounts.textContent = stats.bannedAccounts || 0;
  safeAccounts.textContent = stats.safeAccounts || 0;
  activeReports.textContent = stats.activeReports || 0;
});

// Load initial data
async function loadData() {
  try {
    const [statsRes, historyRes] = await Promise.all([
      fetch('/api/stats'),
      fetch('/api/history')
    ]);
    
    const stats = await statsRes.json();
    const history = await historyRes.json();
    
    if (stats.success) {
      totalReports.textContent = stats.data.totalReports || 0;
      bannedAccounts.textContent = stats.data.bannedAccounts || 0;
      safeAccounts.textContent = stats.data.safeAccounts || 0;
      activeReports.textContent = stats.data.activeReports || 0;
    }
    
    if (history.success) {
      renderHistory(history.data);
    }
  } catch (error) {
    console.error('Load data error:', error);
  }
}

// Render history
function renderHistory(data) {
  if (!data || data.length === 0) {
    historyList.innerHTML = `<div class="empty-state">Belum ada laporan</div>`;
    return;
  }
  
  historyList.innerHTML = data.slice(0, 20).map(item => `
    <div class="history-item">
      <span class="number">${item.number}</span>
      <span class="badge-status ${item.isBanned ? 'badge-banned' : 'badge-safe'}">
        ${item.isBanned ? 'BANNED' : 'SAFE'}
      </span>
      <span class="time">${new Date(item.timestamp).toLocaleTimeString('id-ID')}</span>
    </div>
  `).join('');
}

// Report spam
async function reportNumber(number) {
  const btn = reportBtn;
  btn.disabled = true;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> MENGIRIM...';
  
  try {
    const response = await fetch('/api/report', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ number })
    });
    
    const result = await response.json();
    
    if (result.success) {
      showNotification('✅ Report terkirim!', 'success');
      loadData();
    } else {
      showNotification('❌ Gagal: ' + (result.error || 'Unknown error'), 'error');
    }
  } catch (error) {
    showNotification('❌ Error: ' + error.message, 'error');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<i class="fas fa-paper-plane"></i> SPAM REPORT';
  }
}

// Check status
async function checkStatus(number) {
  const resultDiv = checkResult;
  resultDiv.innerHTML = `
    <div class="status-pill idle">
      <i class="fas fa-spinner fa-spin"></i> Mengecek...
    </div>
  `;
  
  try {
    const response = await fetch('/api/check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ number })
    });
    
    const result = await response.json();
    
    if (result.success) {
      const data = result.data;
      const statusClass = data.isBanned ? 'banned' : 'active';
      const statusText = data.isBanned ? '🚫 TERBAN!' : '✅ AMAN';
      
      resultDiv.innerHTML = `
        <div class="status-pill ${statusClass}">
          <i class="fas ${data.isBanned ? 'fa-ban' : 'fa-check-circle'}"></i>
          ${statusText}
          <span style="font-size:0.8rem;opacity:0.6;margin-left:10px;">${data.number}</span>
        </div>
        <div class="status-details">
          <span>📊 Total Report: ${data.reportCount || 0}</span>
          <span>🕒 Last Checked: ${new Date(data.lastChecked).toLocaleString('id-ID')}</span>
          ${data.isBanned ? `<span>⛔ Reason: ${data.details?.reason || 'Violation'}</span>` : ''}
        </div>
      `;
    } else {
      resultDiv.innerHTML = `
        <div class="status-pill idle">
          <i class="fas fa-exclamation-triangle"></i> Error: ${result.error}
        </div>
      `;
    }
  } catch (error) {
    resultDiv.innerHTML = `
      <div class="status-pill idle">
        <i class="fas fa-exclamation-triangle"></i> Network Error
      </div>
    `;
  }
}

// Bulk report
async function bulkReport() {
  const numbers = targetInput.value.split(',').map(n => n.trim());
  if (numbers.length === 0 || numbers[0] === '') {
    showNotification('❌ Masukkan minimal 1 nomor (pisahkan dengan koma)', 'error');
    return;
  }
  
  const btn = bulkBtn;
  btn.disabled = true;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> PROSES...';
  
  try {
    const response = await fetch('/api/bulk', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ numbers })
    });
    
    const result = await response.json();
    if (result.success) {
      showNotification(`✅ ${result.data.length} nomor berhasil di-report!`, 'success');
      loadData();
    }
  } catch (error) {
    showNotification('❌ Error: ' + error.message, 'error');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<i class="fas fa-layer-group"></i> BULK';
  }
}

// Export data
async function exportData() {
  try {
    const response = await fetch('/api/history');
    const data = await response.json();
    
    if (data.success) {
      const blob = new Blob([JSON.stringify(data.data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `spamguard-history-${Date.now()}.json`;
      a.click();
      URL.revokeObjectURL(url);
      showNotification('✅ Data berhasil diexport!', 'success');
    }
  } catch (error) {
    showNotification('❌ Export error: ' + error.message, 'error');
  }
}

// Clear history
async function clearHistory() {
  if (!confirm('Hapus semua history report?')) return;
  
  try {
    const response = await fetch('/api/clear', { method: 'POST' });
    const result = await response.json();
    if (result.success) {
      showNotification('✅ History cleared!', 'success');
      loadData();
    }
  } catch (error) {
    showNotification('❌ Error: ' + error.message, 'error');
  }
}

// Notification
function showNotification(message, type = 'info') {
  const colors = {
    success: '#00ff99',
    error: '#ff4466',
    info: '#00ffe0'
  };
  
  const div = document.createElement('div');
  div.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: rgba(0, 20, 30, 0.9);
    backdrop-filter: blur(10px);
    padding: 15px 25px;
    border-radius: 16px;
    border-left: 4px solid ${colors[type] || colors.info};
    color: #fff;
    font-family: 'Rajdhani', sans-serif;
    font-weight: 600;
    z-index: 9999;
    box-shadow: 0 10px 40px rgba(0,0,0,0.5);
    animation: slideUp 0.3s ease;
  `;
  div.textContent = message;
  document.body.appendChild(div);
  
  setTimeout(() => {
    div.style.opacity = '0';
    div.style.transition = 'opacity 0.5s';
    setTimeout(() => div.remove(), 500);
  }, 3000);
}

// Event Listeners
reportBtn.addEventListener('click', () => {
  const number = targetInput.value.trim();
  if (!number) {
    showNotification('❌ Masukkan nomor WhatsApp!', 'error');
    return;
  }
  reportNumber(number);
});

checkBtn.addEventListener('click', () => {
  const number = checkInput.value.trim();
  if (!number) {
    showNotification('❌ Masukkan nomor untuk dicek!', 'error');
    return;
  }
  checkStatus(number);
});

bulkBtn.addEventListener('click', bulkReport);
exportBtn.addEventListener('click', exportData);
clearHistoryBtn.addEventListener('click', clearHistory);

// Enter key support
targetInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') reportBtn.click();
});
checkInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') checkBtn.click();
});

// Load data on start
loadData();

// Auto refresh every 10 seconds
setInterval(loadData, 10000);

// Add CSS animation
const style = document.createElement('style');
style.textContent = `
  @keyframes slideUp {
    from { transform: translateY(20px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
  }
`;
document.head.appendChild(style);