const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs-extra');
const http = require('http');
const socketIo = require('socket.io');
const apiRoutes = require('./routes/api');
const spamEngine = require('./services/spamEngine');
const banChecker = require('./services/banChecker');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Socket.io connection
io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);
  
  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
  });
});

// Routes
app.use('/api', apiRoutes);

// Serve dashboard
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Background spam engine - real time
setInterval(async () => {
  const stats = await spamEngine.getStats();
  io.emit('statsUpdate', stats);
}, 5000);

// Auto spam cron (every 30 seconds)
setInterval(() => {
  spamEngine.autoSpam();
}, 30000);

// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`
╔═══════════════════════════════════════╗
║  🚀 SPAMGUARD 3000 ACTIVE            ║
║  📡 Port: ${PORT}                      ║
║  🔥 Engine: REAL SIMULATION          ║
║  👑 Created by: ZAMZZZ               ║
╚═══════════════════════════════════════╝
  `);
});