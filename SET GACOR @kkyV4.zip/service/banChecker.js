const fs = require('fs-extra');
const path = require('path');
const axios = require('axios');

const DB_PATH = path.join(__dirname, '../data/database.json');

class BanChecker {
  constructor() {
    this.db = this.loadDB();
  }

  loadDB() {
    try {
      return fs.readJsonSync(DB_PATH);
    } catch {
      return { banned: {}, reports: [] };
    }
  }

  async check(number) {
    const cleanNumber = this.cleanNumber(number);
    
    // Simulate API call to WhatsApp
    await new Promise(resolve => setTimeout(resolve, 500 + Math.random() * 1000));

    // Check in database
    const isBanned = this.db.banned && this.db.banned[cleanNumber] !== undefined;
    const reportCount = this.db.reports ? 
      this.db.reports.filter(r => r.number === cleanNumber).length : 0;

    // Simulate real-time status
    const status = {
      number: cleanNumber,
      isBanned: isBanned,
      reportCount: reportCount,
      status: isBanned ? 'banned' : 'active',
      lastChecked: new Date().toISOString(),
      details: isBanned ? {
        bannedAt: this.db.banned[cleanNumber]?.bannedAt || new Date().toISOString(),
        reason: this.db.banned[cleanNumber]?.reason || 'Violation of WhatsApp Terms',
        reportsCount: reportCount
      } : {
        lastReport: reportCount > 0 ? 'Recent reports detected' : 'No reports found',
        status: 'clean'
      }
    };

    return status;
  }

  cleanNumber(raw) {
    let cleaned = raw.replace(/\s/g, '').replace(/[^0-9+]/g, '');
    if (!cleaned.startsWith('+')) {
      if (cleaned.startsWith('62')) cleaned = '+' + cleaned;
      else if (cleaned.startsWith('0')) cleaned = '+62' + cleaned.substring(1);
      else cleaned = '+62' + cleaned;
    }
    return cleaned;
  }
}

module.exports = new BanChecker();