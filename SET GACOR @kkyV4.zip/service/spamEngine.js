const fs = require('fs-extra');
const path = require('path');
const axios = require('axios');

const DB_PATH = path.join(__dirname, '../data/database.json');

// Initialize database
class SpamEngine {
  constructor() {
    this.db = this.loadDB();
    this.reportCount = 0;
    this.isRunning = true;
  }

  loadDB() {
    try {
      fs.ensureFileSync(DB_PATH);
      const data = fs.readJsonSync(DB_PATH);
      return data;
    } catch {
      const defaultDB = {
        reports: [],
        banned: {},
        stats: {
          totalReports: 0,
          bannedAccounts: 0,
          safeAccounts: 0
        }
      };
      fs.writeJsonSync(DB_PATH, defaultDB, { spaces: 2 });
      return defaultDB;
    }
  }

  saveDB() {
    fs.writeJsonSync(DB_PATH, this.db, { spaces: 2 });
  }

  // REAL SPAM SIMULATION
  async report(number) {
    // Clean number
    const cleanNumber = this.cleanNumber(number);
    
    // Simulate sending report to WhatsApp servers
    const reportResult = await this.simulateReport(cleanNumber);
    
    // Update database
    this.db.reports.push({
      number: cleanNumber,
      timestamp: new Date().toISOString(),
      status: reportResult.status,
      reportId: `WA-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`
    });

    // Update stats
    this.db.stats.totalReports++;
    
    // Check if account should be banned (realistic simulation)
    const banChance = this.calculateBanProbability(cleanNumber);
    if (banChance > 0.7) {
      this.db.banned[cleanNumber] = {
        bannedAt: new Date().toISOString(),
        reason: 'Excessive spam reports',
        reportsCount: this.countReports(cleanNumber)
      };
      this.db.stats.bannedAccounts++;
      reportResult.isBanned = true;
    }

    this.saveDB();
    this.reportCount++;
    
    return {
      number: cleanNumber,
      ...reportResult,
      totalReports: this.db.stats.totalReports
    };
  }

  // Simulate real WhatsApp API
  async simulateReport(number) {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 300 + Math.random() * 700));

    // Check if number already banned
    if (this.db.banned[number]) {
      return {
        status: 'failed',
        message: 'Akun sudah terban',
        isBanned: true,
        code: 403
      };
    }

    // Random success rate (90% success simulation)
    const success = Math.random() < 0.9;
    
    if (success) {
      return {
        status: 'success',
        message: 'Report terkirim ke WhatsApp',
        isBanned: false,
        code: 200
      };
    } else {
      return {
        status: 'failed',
        message: 'Gagal mengirim report, coba lagi',
        isBanned: false,
        code: 429
      };
    }
  }

  // Calculate ban probability based on reports count
  calculateBanProbability(number) {
    const reportCount = this.countReports(number);
    // Each report increases ban chance
    const baseChance = 0.1;
    const increment = reportCount * 0.08;
    return Math.min(baseChance + increment, 0.95);
  }

  countReports(number) {
    return this.db.reports.filter(r => r.number === number).length;
  }

  cleanNumber(raw) {
    let cleaned = raw.replace(/\s/g, '').replace(/[^0-9+]/g, '');
    if (!cleaned.startsWith('+')) {
      if (cleaned.startsWith('62')) cleaned = '+' + cleaned;
      else if (cleaned.startsWith('0')) cleaned = '+62' + cleaned.substring(1);
      else cleaned = '+62' + cleaned;
    }
    return cleaned;
  }

  async getStats() {
    return {
      totalReports: this.db.stats.totalReports,
      bannedAccounts: this.db.stats.bannedAccounts,
      safeAccounts: this.db.stats.safeAccounts,
      activeReports: this.db.reports.length
    };
  }

  async getHistory() {
    return this.db.reports.slice(-50).reverse();
  }

  // Auto spam for testing
  async autoSpam() {
    if (!this.isRunning) return;
    
    const testNumbers = [
      '+6281234567890',
      '+6289876543210',
      '+628111222333',
      '+628555666777',
      '+628999888777'
    ];
    
    const randomNumber = testNumbers[Math.floor(Math.random() * testNumbers.length)];
    await this.report(randomNumber);
    
    console.log(`[AUTO] Reported: ${randomNumber}`);
  }
}

module.exports = new SpamEngine();