const express = require('express');
const router = express.Router();
const spamEngine = require('../services/spamEngine');
const banChecker = require('../services/banChecker');

// Report spam
router.post('/report', async (req, res) => {
  const { number } = req.body;
  
  if (!number) {
    return res.status(400).json({ error: 'Nomor WhatsApp wajib diisi' });
  }
  
  try {
    const result = await spamEngine.report(number);
    res.json({
      success: true,
      message: `Report sent to ${number}`,
      data: result
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Check status
router.post('/check', async (req, res) => {
  const { number } = req.body;
  
  if (!number) {
    return res.status(400).json({ error: 'Nomor WhatsApp wajib diisi' });
  }
  
  try {
    const status = await banChecker.check(number);
    res.json({
      success: true,
      data: status
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Get stats
router.get('/stats', async (req, res) => {
  try {
    const stats = await spamEngine.getStats();
    res.json({
      success: true,
      data: stats
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Get report history
router.get('/history', async (req, res) => {
  try {
    const history = await spamEngine.getHistory();
    res.json({
      success: true,
      data: history
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Bulk report
router.post('/bulk', async (req, res) => {
  const { numbers } = req.body;
  
  if (!numbers || !Array.isArray(numbers)) {
    return res.status(400).json({ error: 'Kirim array nomor' });
  }
  
  try {
    const results = [];
    for (const number of numbers) {
      const result = await spamEngine.report(number);
      results.push(result);
      // Delay biar ga ke-deteksi spam
      await new Promise(resolve => setTimeout(resolve, 200));
    }
    res.json({
      success: true,
      data: results
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

module.exports = router;